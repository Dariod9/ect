package aula12.Ex2;

public interface IPlugin {
	public void fazQualQuerCoisa ();
	}   