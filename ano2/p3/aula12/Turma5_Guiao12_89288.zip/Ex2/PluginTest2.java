package aula12.Ex2;

public class PluginTest2 implements IPlugin {

	@Override
	public void fazQualQuerCoisa() {
		System.out.println("What's this x2");
		
	}

	
}
