package aula12.Ex1;

public interface SimpleInterface {

	public void doesStuff();
}
