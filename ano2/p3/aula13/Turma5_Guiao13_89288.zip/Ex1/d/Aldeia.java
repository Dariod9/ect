package aula13.Ex1.d;

public class Aldeia extends Localidade {

	public Aldeia(String nome, int pop) {
		super(nome, pop);
	}

}
