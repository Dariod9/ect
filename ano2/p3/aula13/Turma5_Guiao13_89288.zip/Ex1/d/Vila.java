package aula13.Ex1.d;

public class Vila extends Localidade {

	public Vila(String nome, int pop) {
		super(nome, pop);
	}

}
