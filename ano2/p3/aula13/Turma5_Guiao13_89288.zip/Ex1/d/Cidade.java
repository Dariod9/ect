package aula13.Ex1.d;

public class Cidade extends Localidade {

	public Cidade(String nome, int pop) {
		super(nome, pop);
	}

}
