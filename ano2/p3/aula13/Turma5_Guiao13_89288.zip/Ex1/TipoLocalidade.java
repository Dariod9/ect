package aula13.Ex1;

public enum TipoLocalidade {
		CIDADE, VILA, ALDEIA
}
