package aula5.Ex2;

public enum Tipo {
	 INEM, Bombeiros, GNR, PSP, PJ
}
