package aula5.Ex2;

public abstract class Automovel extends Veiculo{
	
	public Automovel(int ano, String matr, String cor, int rodas, int cilind, int velM) {
		super(ano, matr, cor, rodas,cilind,velM);
	}
	
}