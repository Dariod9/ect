package aula5.Ex2;

public interface Policia {
	
	public Tipo tipo();
	public int id();
	
}