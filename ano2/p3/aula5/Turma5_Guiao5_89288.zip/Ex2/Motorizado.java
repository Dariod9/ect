package aula5.Ex2;

public interface Motorizado{
	
	public int getPotencia();
	public double getConsumo();
	public String getCombustivel();
	
}