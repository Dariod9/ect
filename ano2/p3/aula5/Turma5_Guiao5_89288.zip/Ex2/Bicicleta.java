package aula5.Ex2;

public class Bicicleta extends Veiculo{
	
	public Bicicleta(int ano, String cor) {
		super(ano,"null",cor,2,0,30);
	}
}