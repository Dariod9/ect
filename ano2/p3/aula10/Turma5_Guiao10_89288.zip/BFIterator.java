package aula10;

public interface BFIterator {
	
	boolean hasPrevious();
	Object previous();
	boolean hasNext();
	Object next();
}