x=1:6;
px=ones(1,6)/6;
subplot(1,2,1)
stem(x,px)
axis([0,6,0,0.2]);
xlabel('x');
ylabel('p_x(x)')

