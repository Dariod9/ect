val=[1:4];
f=(val+5)./30;

if (min(f) >= 0 && max(f) <= 1 && sum(f) == 1)
    disp('A funcao f(x) = (x + 5) / 30 pode representar a variavel aleatoria com os valores 1, 2, 3 e 4 \n')
else 
    disp('A funcao f(x) = (x + 5) / 30 pode representar a variavel aleatoria com os valores 1, 2, 3 e 4 \n')
end