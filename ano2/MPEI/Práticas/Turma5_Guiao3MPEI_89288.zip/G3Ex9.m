 lambda=1;
 
 #p(>=1)=1-p(0)

disp("Probabilidade de pelo menos um erro: ") 
 prob=1-(lambda^0)*(exp(-lambda))/factorial(0)
