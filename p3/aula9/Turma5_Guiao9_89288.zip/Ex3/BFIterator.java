package aula9.Ex3;

public interface BFIterator {
	
	boolean hasPrevious();
	Object previous();
	boolean hasNext();
	Object next();
}