package aula9.Ex2;

public interface Gelado {

	public void base(int n);
	
}

