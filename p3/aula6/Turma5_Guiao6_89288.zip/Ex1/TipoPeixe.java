package aula6.Ex1;

public enum TipoPeixe {
	 Congelado, Fresco;
}
