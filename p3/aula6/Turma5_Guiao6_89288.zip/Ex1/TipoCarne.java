package aula6.Ex1;

public enum TipoCarne {
	 VACA, PORCO, PERU , FRANGO, OUTRA;
}
