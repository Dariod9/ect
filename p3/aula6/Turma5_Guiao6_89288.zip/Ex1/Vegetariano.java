package aula6.Ex1;

public interface Vegetariano {

}
