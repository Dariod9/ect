package aula11.Ex1.a;

public interface BFIterator {
	
	boolean hasPrevious();
	Object previous();
	boolean hasNext();
	Object next();
}