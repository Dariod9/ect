package aula11.Ex1.b;

import java.io.IOException;

public class TestRead {
	public static void main(String[] args) throws IOException {
	
	String nome="ficheiro";
	ReadDifferent r= new ReadDifferent(nome);
}
}
