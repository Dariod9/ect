package aula7.Ex1;

public class Companhia {

	private String nomeC;

	
	
	public Companhia(String nomeC) {
		this.nomeC=nomeC;
	}
	
	public String nomeC() { return nomeC;}
}
