public class Contacto {
  private String nome;
  private String telefone;
}
